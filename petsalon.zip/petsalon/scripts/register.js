let petID=0;

//constructor
function Pet(n,a,g,b,s,t,p){
    this.name=n;
    this.age=a;
    this.gender=g;
    this.breed=b;
    this.service=s;
    this.type=t;
    this.payment=p;
    this.id=petID++;
}

function getE(id){
    return document.getElementById(id);
}
//get elements from HTML
let inputName= getE("txtName");
let inputAge= getE("txtAge");
let inputGender= getE("txtGender");
let inputBreed=getE("txtBreed");
let inputService=getE("txtService");
let inputType=getE("txtType");
let inputPayment=getE("txtPayment");

function isValid(aPet){
    let validation=true;
    //clear the style
    //document.querySelectorAll("inputs");
    getE("txtName").classList.remove("alert-error");
    getE("txtAge").classList.remove("alert-error");
    if(aPet.name==""){
        //the pet is not valid
        validation=false;
        getE("txtName").classList.add("alert-error");
    }
    if(aPet.age==""){
        validation=false;
        getE("txtAge").classList.add("alert-error");
    }
    return validation;
}

function showNotifications(msg,type){
    //getE("notifications").classList.remove("hidden");
    $("#notifications").slideDown(1000);
    getE("notifications").innerHTML=`<p class="${type}">${msg} </p>`;
    $("#notifications").slideUp(1000);
    
    //setTimeout(function(){
    //  getE("notifications").classList.add("hidden");
    //  },3000);
}
function register(){
    //1)getting value
    //2) create the newPet using the constructor
    let newPet = new Pet(inputName.value,inputAge.value,inputGender.value,inputBreed.value,inputService.value,inputType.value,inputPayment.value);
    console.log(newPet);

    if(isValid(newPet)==true){
        //3) push the newPet to the array
        salon.pets.push(newPet);
        //4) call display function
        saveItem(newPet,"petsDB");
        displayPetCards();
        //5) clear the input
        inputName.value="";
        inputAge.value="";
        inputGender.value="";
        inputBreed.value="";
        inputService.value="";
        inputType.value="";
        inputPayment.value="";

        showNotifications("Successful registration","alert-success");
    }else{
        showNotifications("Please fill out all the required fields","alert-error");
    }
}
function deletePet(petID){
    let deleteIndex;
    for(let i=0;i<salon.pets.length;i++){
        let pet = salon.pets[i];
        if(pet.id==petID){
            deleteIndex=i;
        break;
        }
    }
    getE(id).remove();
    salon.pets.splice(deleteIndex,1);
}

function getServices(){
    let servicesList = readItems("services");
    for(let i=0;i<servicesList.length;i++){
        let service = servicesList[i];
        $("#pet-Service").append(
            `<option value="${service.description}">${service.description}</option>`
        );
    }
}
function displayRegisteredPetsInTable() {
    // Get the table element from the HTML
    let table = document.getElementById("registeredPetsTable");

    // Clear existing table rows
    table.innerHTML = "";

    // Create table header row
    let headerRow = table.insertRow();
    let headers = ["Name", "Age", "Gender", "Breed", "Service", "Type", "Payment","Id" ];
    headers.forEach(headerText => {
        let headerCell = headerRow.insertCell();
        headerCell.textContent = headerText;
    });

    // Iterate through the salon's pets array and add each pet to the table
    salon.pets.forEach(pet => {
        let row = table.insertRow();
        Object.values(pet).forEach(value => {
            let cell = row.insertCell();
            cell.textContent = value;
        });
    });
}
function init(){
    //creating predefined 
    let pet1=new Pet("Dave",4,"Male","Donkey","Nails","Other","Credit");
    let pet2=new Pet("Burt",13,"Male","Bear","Grooming","Other","Credit");
    let pet3=new Pet("Speedy",70,"Female","Lab","Nails","Dog","Credit");
    let pet4=new Pet("Scooby",60,"Male","Cow","Grooming","other","Cash");
    let pet5=new Pet("Baby",50,"Female","Tabby","Vaccine","Cat","Check");
    let pet6=new Pet("JuneBug",70,"Female","BullDog","Grooming","Dog","Credit");
    salon.pets.push(pet1,pet2,pet3,pet4,pet5,pet6);
    getServices();
    //exacuting fn
    // displayPetCards();
    
    
    // Call the function to display registered pets in a table
    displayRegisteredPetsInTable();
}
window.onload=init;// wait to render the HTML